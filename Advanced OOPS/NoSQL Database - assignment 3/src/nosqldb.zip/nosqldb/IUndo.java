package nosqldb;

public interface IUndo {
    Object undo();
}
