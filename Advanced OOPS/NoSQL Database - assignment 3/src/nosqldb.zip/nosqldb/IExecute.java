package nosqldb;

public interface IExecute {
    Object execute();
}
