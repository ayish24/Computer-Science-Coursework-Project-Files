package nosqldb;

public interface ISerialize {
    String serialize();
}
